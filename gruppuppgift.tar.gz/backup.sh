#!/bin/bash

sudo mysqldump --databases dev_to >/home/dev/Desktop/dev_to_backup.sql 


