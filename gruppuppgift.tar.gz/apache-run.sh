#!/bin/bash

if [ `systemctl is-active apache2` != "active" ]
then
		  zenity --notification  --text "Apache service is down! Restarting" --display=:0.0 --height 100 --width 500
                      systemctl restart apache2
fi

